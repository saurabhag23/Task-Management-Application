package com.ood.project.TrelloClone.controller;

import com.ood.project.TrelloClone.model.enitity.Task;
import com.ood.project.TrelloClone.model.enitity.TaskHistoryTable;
import com.ood.project.TrelloClone.model.task.ModifyTaskRequest;
import com.ood.project.TrelloClone.model.task.TaskResponse;
import com.ood.project.TrelloClone.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/tasks")
public class TaskController {
    private final TaskService taskService;


    /**
     * get the task body of a particular taskID
     */
    @GetMapping("/get")
    public ResponseEntity<TaskResponse> getTaskById(@RequestParam long taskID) {
        return ResponseEntity.ok().body(taskService.getTask(taskID));
    }

    /**
     * getAll shows Board, return list of all tasks in order of TODO --> DOING --> DONE
     */
    @GetMapping("/getAll")
    public ResponseEntity<List<TaskResponse>> getTasks() {
        return ResponseEntity.ok().body(taskService.getAllTask());
    }

    /**
     * add a task with taskname and description, taskid increments and user=NULL,
     * saves time of creation ,default status --> TODO
     */
    @PostMapping("/add")
    public ResponseEntity<TaskResponse> add(@RequestBody Task task) {
        return ResponseEntity.ok().body(taskService.saveTask(task));
    }

    /**
     * given the taskid, modify the task and updated time of task is set to current timestamp
     * can change the assigned users,change status,add comment and edit description
     */
    @PutMapping("/modify")
    public ResponseEntity<TaskResponse> modify(@RequestBody ModifyTaskRequest task) {
        return ResponseEntity.ok().body(taskService.modifyTask(task));
    }

    /**
     * deletes the task with particular task id, return Success/Failure
     */
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteTask(@RequestParam long taskID) {
        taskService.deleteTaskByID(taskID);
        return ResponseEntity.ok("Deleted task with taskId: " + taskID);
    }

    /**
     * given the taskID, returns the list of history of modifications on task
     */
    @GetMapping("/getHistory")
    public ResponseEntity<List<TaskHistoryTable>> getTaskHistoryById(@RequestParam long taskID) {
        return ResponseEntity.ok().body(taskService.getHistoryTable(taskID));
    }



}
