package com.ood.project.TrelloClone.service;

import com.ood.project.TrelloClone.model.enitity.Task;
import com.ood.project.TrelloClone.model.enitity.TaskComment;
import com.ood.project.TrelloClone.model.enitity.TaskHistoryTable;
import com.ood.project.TrelloClone.model.enitity.TaskUsers;
import com.ood.project.TrelloClone.model.task.ModifyTaskRequest;
import com.ood.project.TrelloClone.model.task.Status;
import com.ood.project.TrelloClone.model.task.TaskResponse;
import com.ood.project.TrelloClone.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {
    private final TaskRepository taskRepo;
    private final UserRepository userRepo;
    private final TaskCommentRepository taskCommentRepo;
    private final TaskUsersRepository taskUsersRepo;
    private final TaskHistoryTableRepository taskHistoryTableRepository;

    private final DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
    private static final String STATUS_CHANGE = "nextStatus";

    @Override
    public TaskResponse saveTask(Task task) {
        task.setStatus(Status.TODO);
        if(task.getETC() == null)
            task.setETC("3 days");
        task.setTimeCreated(getTime());
        taskRepo.save(task);
        return getTaskResponse(task);
    }

    @Override
    public TaskResponse getTask(long taskID) {
        Task task = taskRepo.findByTaskID(taskID);
        return getTaskResponse(task);
    }

    @Override
    public List<TaskResponse> getAllTask() {
        List<TaskResponse> taskList = new ArrayList<>();
        List<Task> tasks = taskRepo.findByOrderByStatusAsc();
        for (Task task : tasks) {
            taskList.add(getTaskResponse(task));
        }
        return taskList;
    }

    @Override
    public TaskResponse modifyTask(ModifyTaskRequest modifyTaskRequest) {

        Task taskFromRepo = taskRepo.findByTaskID(modifyTaskRequest.getTaskID());
        if (modifyTaskRequest.getTaskName() != null) {
            saveToTaskHistory(taskFromRepo);
            taskFromRepo.setTaskName(modifyTaskRequest.getTaskName());
        }
        if (modifyTaskRequest.getDescription() != null) {
            saveToTaskHistory(taskFromRepo);
            taskFromRepo.setDescription(modifyTaskRequest.getDescription());
        }
        if (modifyTaskRequest.getStatus() != null) {
            if (taskUsersRepo.findByTask(taskFromRepo) != null) {
                if (modifyTaskRequest.getStatus().equalsIgnoreCase(STATUS_CHANGE)) {
                    saveToTaskHistory(taskFromRepo);
                    taskFromRepo.setStatus(taskFromRepo.getStatus().next());
                }
            }
        }
        if (modifyTaskRequest.getComment() != null) {
            TaskComment taskComment = TaskComment.builder()
                    .task(taskFromRepo)
                    .comment(modifyTaskRequest.getComment())
                    .userDetails(userRepo.findByUserID(modifyTaskRequest.getUserID()))
                    .build();
            taskCommentRepo.save(taskComment);
        }
        if (modifyTaskRequest.getUserID() != 0) {
            TaskUsers taskUsers = TaskUsers.builder()
                    .task(taskFromRepo)
                    .userDetails(userRepo.findByUserID(modifyTaskRequest.getUserID()))
                    .build();
            taskUsersRepo.save(taskUsers);
        }
        taskFromRepo.setTimeUpdated(getTime());
        taskRepo.save(taskFromRepo);
        return getTaskResponse(taskFromRepo);
    }

    @Override
    public void deleteTaskByID(long taskID) {
        taskRepo.deleteById(taskID);
    }

    @Override
    public List<TaskHistoryTable> getHistoryTable(long taskID) {
        return taskHistoryTableRepository.findByTaskID(taskID);
    }

    private TaskResponse getTaskResponse(Task task){
        return TaskResponse.builder().task(task)
                .comments(taskCommentRepo.findByTask(task).stream().map(TaskComment::getComment).collect(Collectors.toList()))
                .userDetails(taskUsersRepo.findByTask(task).stream().map(TaskUsers::getUserDetails).collect(Collectors.toList()))
                .build();
    }

    private void saveToTaskHistory(Task task) {
        TaskHistoryTable taskHistoryTable = TaskHistoryTable.builder()
                .taskID(task.getTaskID())
                .taskName(task.getTaskName())
                .ETC(task.getETC())
                .status(task.getStatus())
                .description(task.getDescription())
                .timeCreated(task.getTimeCreated())
                .timeUpdated(getTime())
                .build();
        taskHistoryTableRepository.save(taskHistoryTable);
    }

    private String getTime(){
        LocalDateTime obj = LocalDateTime.now();
        return obj.format(format);
    }
}
