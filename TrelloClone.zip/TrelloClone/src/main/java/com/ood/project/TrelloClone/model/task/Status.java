package com.ood.project.TrelloClone.model.task;

// TODO-->DOING-->DONE
public enum Status {
    TODO {
        public Status next() {
            return DOING;
        }
    },
    DOING {
        public Status next() {
            return DONE;
        }
    },
    DONE {
        public Status next() {
            return TODO;
        }
    };

    public abstract Status next();
}
